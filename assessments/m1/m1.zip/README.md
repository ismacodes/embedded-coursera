/* Add Author and Project Details here */
Author: Ismael Castro

A small program that returns statistics about a dataset. Expected datasets are just arrays of unsigned char's. 
